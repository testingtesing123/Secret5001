GrowthCraft Hops 3.1
====================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.1
GrowthCraft Core 2.1
GrowthCraft Core: Cellar 2.1

----------------
Default IDs Used
----------------
Blocks : 505, 506, 507
Items  : 5009, 5010, 5011, 5012, 5013, 5014

----------------
Vanilla Edits
----------------
x

------------
Installation
------------
1. Install the requirements.
4. Place "growthcraft-hops-1.5.2-3.1" to your mods folder.
