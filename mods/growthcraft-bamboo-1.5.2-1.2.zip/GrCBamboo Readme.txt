GrowthCraft Bamboo 1.2
======================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.1
GrowthCraft Core 2.1

----------------
Default IDs Used
----------------
Blocks : 516, 517, 518, 519, 520, 521, 522, 523, 524, 525
Items  : 5023, 5024

----------------
Vanilla Edits
----------------
x

------------
Installation
------------
1. Install the requirements.
2. Place "growthcraft-bamboo-1.5.2-1.2" to your mods folder.
