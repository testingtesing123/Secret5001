GrowthCraft Apples 4.2
======================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.1
GrowthCraft Core 2.1
GrowthCraft Core: Booze 2.1

----------------
Default IDs Used
----------------
Blocks : 500, 501
Items  : 5000, 5001, 5002, 5003

----------------
Vanilla Edits
----------------
Item - Apple

------------
Installation
------------
1. Install the requirements.
2. Place "growthcraft-apples-1.5.2-4.2" to your mods folder.
