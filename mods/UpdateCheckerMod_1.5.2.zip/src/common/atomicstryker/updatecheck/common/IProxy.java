package atomicstryker.updatecheck.common;

public interface IProxy
{
    public void announce(String announcement);
}
