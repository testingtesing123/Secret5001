GrowthCraft Rice 1.1
====================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.1
GrowthCraft Core 2.1
GrowthCraft Core: Cellar 2.1

----------------
Default IDs Used
----------------
Blocks : 513, 514, 515
Items  : 5017, 5018, 5019, 5020, 5021, 5022

----------------
Vanilla Edits
----------------
x

------------
Installation
------------
1. Install the requirements.
4. Place "growthcraft-rice-1.5.2-1.1" to your mods folder.
