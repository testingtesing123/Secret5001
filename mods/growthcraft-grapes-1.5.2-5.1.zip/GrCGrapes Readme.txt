GrowthCraft Grapes 5.1
======================

-----------
Requirement
-----------
MineCraft 1.5.2
Forge 7.8.1
GrowthCraft Core 2.1
GrowthCraft Core: Cellar 2.1

----------------
Default IDs Used
----------------
Blocks : 502, 503, 504
Items  : 5004, 5005, 5006,5007, 5008

----------------
Vanilla Edits
----------------
x

------------
Installation
------------
1. Install the requirements.
4. Place "growthcraft-grapes-1.5.2-5.1" to your mods folder.
