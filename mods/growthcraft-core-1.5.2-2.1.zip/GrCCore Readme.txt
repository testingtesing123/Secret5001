GrowthCraft Core 2.1
======================

------------
Requirements
------------
MineCraft 1.5.2
Forge 7.8.1

----------------
Default IDs Used
----------------
x

----------------
Vanilla Edits
----------------
x

------------
Installation
------------
1. Install the requirements.
2. Place "growthcraft-core-1.5.2-2.1" to your mods folder.
